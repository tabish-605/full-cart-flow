const express = require('express');
const router = express.Router();
const CartItem = require('../models/CartItem');

router.get('/', async (req, res) => {
  const items = await CartItem.find().populate('product');
  res.json(items);
});

router.post('/', async (req, res) => {
  const { productId, quantity } = req.body;
  let item = await CartItem.findOne({ product: productId });
  if (item) {
    item.quantity += quantity;
  } else {
    item = new CartItem({ product: productId, quantity });
  }
  await item.save();
  res.json(item);
});

router.put('/:id', async (req, res) => {
  const { quantity } = req.body;
  const item = await CartItem.findByIdAndUpdate(req.params.id, { quantity }, { new: true }).populate('product');
  res.json(item);
});

router.delete('/:id', async (req, res) => {
  await CartItem.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

module.exports = router;
