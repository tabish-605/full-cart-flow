const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');

router.get('/', async (req, res) => {
  const orders = await Order.find().populate('items.product');
  res.json(orders);
});

router.post('/', async (req, res) => {
  const { items } = req.body;
  const populatedItems = items.map(i => ({ product: i.productId, quantity: i.quantity }));

  const total = await items.reduce(async (sumPromise, i) => {
    const sum = await sumPromise;
    const product = await Product.findById(i.productId);
    return sum + (product.price * i.quantity);
  }, Promise.resolve(0));

  const order = new Order({ items: populatedItems, total });
  await order.save();
  res.json(order);
});

module.exports = router;
